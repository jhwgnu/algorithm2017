g++ HairpinDetector.cpp -o HairpinDetector
./HairpinDetector DNAseq.fasta
